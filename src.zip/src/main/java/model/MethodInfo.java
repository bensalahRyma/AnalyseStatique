package model;

public class MethodInfo {
    public String name, signature;
    public int paramCount;
    public int srcStart, srcLen;
}
